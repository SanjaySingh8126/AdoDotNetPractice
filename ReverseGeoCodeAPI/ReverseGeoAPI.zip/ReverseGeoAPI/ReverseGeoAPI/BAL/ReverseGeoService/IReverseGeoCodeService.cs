﻿using ReverseGeoAPI.Model;

namespace ReverseGeoAPI.BAL.ReverseGeoService
{
	public interface IReverseGeoCodeService
	{
	  void ReverseGeoCode();
	}
}
